# Inspeção Sanitária de Mercados

Ferramenta **exclusivamente didática** da Profa. Dra. Larissa Castor Ramos para treinar a avaliação higiênico-sanitária de feiras livres, mercados municipais e supermercados (ambiente geral, laticínios, carne bovina, aves e pescados), com escala Likert, índices, estatística descritiva e relatório em PDF.

Não substitui a inspeção oficial e não tem validade como termo de inspeção, auto de infração ou laudo.

## Privacidade

- Site 100% estático: sem servidor, sem banco de dados, sem cookies, sem rastreamento.
- Nenhuma avaliação é gravada (nem em `localStorage`). Os dados ficam só na memória da aba de cada aluno e somem ao fechar ou recarregar a página.
- O PDF é gerado no próprio aparelho (biblioteca jsPDF, em `vendor/`) e baixado direto pelo navegador.

## Arquivos

| Arquivo | Função |
|---|---|
| `index.html` | Aplicação completa (HTML, CSS, JS e logomarca embutida) |
| `vendor/jspdf.umd.min.js` | jsPDF 2.5.1 (MIT), incluída localmente para funcionar offline |
| `logo.png` | Logomarca (ícone da aba) |
| `.nojekyll` | Faz o GitHub Pages servir os arquivos como estão |

Só as fontes (IBM Plex e Source Serif, do Google Fonts) vêm da internet; sem conexão o site usa fontes do sistema e continua funcionando.

## Publicar no GitHub Pages

1. Crie um repositório no GitHub (por exemplo `inspecao-mercados`).
2. Envie todos os arquivos desta pasta para a raiz do repositório (`Add file > Upload files`, ou `git push`).
3. Em **Settings > Pages**, em *Build and deployment*, escolha **Deploy from a branch**, branch `main`, pasta `/ (root)`, e salve.
4. Em alguns minutos o site fica em `https://SEU-USUARIO.github.io/inspecao-mercados/`. Compartilhe esse link com os alunos.

## Testar localmente

Abra `index.html` no navegador (duplo clique) ou rode `python3 -m http.server` na pasta e acesse `http://localhost:8000`.

## Ajustes comuns

- **Itens e base legal:** objeto `DEF` no início do `<script>` de `index.html`. Cada item é `[texto, crítico (0/1), referência]`.
- **Pesos e classes:** `CLS` (faixas de classificação) e a linha `M.global=0.3*gp+0.7*sm` (peso do ambiente geral e dos setores).
- **Legislação exibida:** vetor `LAW`.
